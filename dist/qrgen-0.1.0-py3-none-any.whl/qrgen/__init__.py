"""QR code generator package."""

from .generator import generate_qr

__all__ = ["generate_qr"]